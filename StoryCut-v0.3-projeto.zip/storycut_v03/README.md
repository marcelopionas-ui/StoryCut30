# StoryCut — v0.3 (protótipo Android)

Recursos implementados no código: duração editável; exportação sequencial com Media3; serviço foreground para processamento com notificação; progresso percentual estimado via Transformer; takes prontos liberados durante processamento; seleção de takes anterior/próximo; estados locais de confirmação/reenvio; cópia de perfis para marcação manual; exclusão confirmada dos takes gerados sem apagar o vídeo original.

## Limitações importantes
- **Não há publicação automática pela API Meta** nem inserção automática de menções. Conta pessoal usa editor do Instagram e confirmação manual. Conta empresarial aparece apenas como opção preparatória.
- A exportação em segundo plano pode ser encerrada pelo Android, pela bateria ou pela parada forçada. Retomada automática após encerramento do serviço **ainda não implementada**.
- O app ainda não foi compilado/testado nesta versão. É necessário rodar GitHub Actions e corrigir eventuais erros.
- Os arquivos de vídeo gerados ficam no diretório privado de mídia do aplicativo e ocupam espaço até serem excluídos.
- Progresso percentual é aproximado. Não há garantia de precisão de quadros em todas as fontes/formatos.
- A permissão de notificações no Android 13+ ainda precisa de solicitação em tempo de execução para mostrar notificações na gaveta.

## Instalação via GitHub
Envie os arquivos extraídos ao repositório (ou use Codespaces para extrair ZIP), confirme o commit e veja Actions > Gerar APK StoryCut > Artifacts.
